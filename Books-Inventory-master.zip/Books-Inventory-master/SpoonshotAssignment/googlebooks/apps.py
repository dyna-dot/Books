from django.apps import AppConfig


class GooglebooksConfig(AppConfig):
    name = 'googlebooks'
